package mshaik.meru.online.pricing;

import static org.junit.Assert.assertNotNull;

import java.util.Optional;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;
import org.springframework.test.context.junit4.SpringRunner;

import mshaik.meru.online.pricing.entities.ProductPrice;
import mshaik.meru.online.pricing.repository.ProductPriceRepository;

@RunWith(SpringRunner.class)
@DataJpaTest
public class ProductPriceControllerTests 
{
	@Autowired
	private ProductPriceRepository repo;

	@Test
	public void testAddandGetProductPriceTests()
	{		
		ProductPrice priceadd = new ProductPrice(5001L,2500L,7);
		ProductPrice price1 =  repo.save(priceadd);
        
		Optional<ProductPrice> priceopt = repo.findById(price1.getProdId());
		ProductPrice price2 = priceopt.get();
        assertNotNull(price2);		
	}
	
	@Test
	public void testDeleteProductPriceTests()
	{
		ProductPrice priceadd = new ProductPrice(5001L,2500L,7);
		ProductPrice price1 =  repo.save(priceadd);
        repo.delete(price1);
	}
	
    @Test
    public void deletByEmployeeIdTest() {
		ProductPrice priceadd = new ProductPrice(5001L,2500L,7);
		ProductPrice price1 =  repo.save(priceadd);
		repo.deleteById(price1.getProdId());
    }
}
