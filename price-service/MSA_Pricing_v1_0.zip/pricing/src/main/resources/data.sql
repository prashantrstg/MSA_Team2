insert into product_price(prod_id, price, tax) values(1001, 2000, 7);
insert into product_price(prod_id, price, tax) values(1002, 4000, 7);
insert into product_price(prod_id, price, tax) values(1003, 6000, 8);