package mshaik.meru.online.pricing;

import java.util.Optional;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import mshaik.meru.online.pricing.entities.ProductPrice;
import mshaik.meru.online.pricing.repository.ProductPriceRepository;
import mshaik.meru.online.pricing.exception.ResourceNotFoundException;

@RestController
public class ProductPriceController 
{
	@Autowired
	private ProductPriceRepository repo;
	
	//Retrieving Product Price
	@GetMapping("/meru/product/price/{prodid}")   
	public ProductPrice retrieveProductPrice(@PathVariable long prodid) 
	{		
		Optional<ProductPrice> price =  repo.findById(prodid);
		if(!price.isPresent())
		{
			throw new ResourceNotFoundException("Product id-" + prodid);
		}
		return price.get();
	}

	//Modifying Product Price
	@PostMapping("/meru/product/price/{prodid}")   
	public ProductPrice modifyProductPrice(@RequestBody ProductPrice chgprice) 
	{		
		Optional<ProductPrice> priceopt =  repo.findById(chgprice.getProdId());
		if(!priceopt.isPresent())
		{
			throw new ResourceNotFoundException("Product id-" + priceopt.get().getProdId());
		}
		
		//get the existing object and assign to new price
		//then modify stuff as we given
		ProductPrice newprice =  priceopt.get();
		newprice.setPrice(chgprice.getPrice());
		newprice.setTax(chgprice.getTax());

		return repo.save(newprice);
	}

	 //Add Product Price
	@PostMapping("/meru/product/price") 
	public ProductPrice addProductPrice(@Valid @RequestBody ProductPrice prodprice) 
	{		
		ProductPrice price =  repo.save(prodprice);
		return price;
	}
	
	 //Delete Product Price
	@DeleteMapping("/meru/product/price/{prodid}")
	public void deleteProductPrice(@PathVariable long prodid) 
	{		
		Optional<ProductPrice> price =  repo.findById(prodid);
		if(!price.isPresent())
		{
			throw new ResourceNotFoundException("Product id-" + prodid);
		}
		repo.deleteById(prodid);
	}
}