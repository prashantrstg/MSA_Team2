package mshaik.meru.online.pricing;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;

import javax.ws.rs.core.Application;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.web.client.TestRestTemplate;
import org.springframework.boot.web.server.LocalServerPort;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.web.client.HttpClientErrorException;

import mshaik.meru.online.pricing.entities.ProductPrice;


@RunWith(SpringRunner.class)
@SpringBootTest(classes = Application.class, webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT)
public class PricingControllerIntegrationTests 
{
    @Autowired
    private TestRestTemplate restTemplate;

    @LocalServerPort
    private int port;

    private String getRootUrl() {
        return "http://localhost:" + port;
    }
    
    @Test
    public void contextLoads() 
    {
    }
    
    @Test
    public void testGetProdPriceById() 
    {
    	ProductPrice price = restTemplate.getForObject(getRootUrl() + "/meru/product/price/1001" , ProductPrice.class);
        System.out.println("DEBUGG-->" + price.toString());
        assertNotNull(price);
    }
    
    @Test
    public void testCreateProdPrice() 
    {
		ProductPrice priceadd = new ProductPrice(5002L,2500L,7);
		ResponseEntity<ProductPrice> postResponse = restTemplate.postForEntity(getRootUrl() + "/meru/product/price", priceadd, ProductPrice.class);
        assertNotNull(postResponse);
        assertNotNull(postResponse.getBody());
        System.out.println("DEBUGG-->" + postResponse.getBody());
    }

    @Test
    public void deleteProdPrice() 
    {
    	//Add Product price first
		ProductPrice priceadd = new ProductPrice(5002L,2500L,7);
		ResponseEntity<ProductPrice> postResponse = restTemplate.postForEntity(getRootUrl() + "/meru/product/price",priceadd, ProductPrice.class);

        restTemplate.delete(getRootUrl() + "/employees/5002");
        try 
        {
        	ProductPrice price = restTemplate.getForObject(getRootUrl() + "/employees/5002", ProductPrice.class);
        } 
        catch (final HttpClientErrorException e) 
        {
            assertEquals(e.getStatusCode(), HttpStatus.NOT_FOUND);
        }
    }
}