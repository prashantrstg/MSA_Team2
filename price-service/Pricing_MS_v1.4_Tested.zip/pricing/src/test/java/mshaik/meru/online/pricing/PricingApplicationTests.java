package mshaik.meru.online.pricing;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PricingApplicationTests {

	@Test
	void contextLoads() {
	}

}
