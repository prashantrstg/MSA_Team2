package prstg.meru.online.promotion.repository;
import org.springframework.data.repository.CrudRepository;

import prstg.meru.online.promotion.entities.ProductPromotion;
public interface ProductPromotionRepository extends  CrudRepository<ProductPromotion,Long>{

}
