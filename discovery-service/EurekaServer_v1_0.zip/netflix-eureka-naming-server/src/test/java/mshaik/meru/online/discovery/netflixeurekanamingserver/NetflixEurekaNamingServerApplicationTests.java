package mshaik.meru.online.discovery.netflixeurekanamingserver;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class NetflixEurekaNamingServerApplicationTests {

	@Test
	void contextLoads() {
	}

}
