package meru.product.service.product_service.exception;

public class ResourceNotFoundException extends Exception{
	public ResourceNotFoundException() {
		// TODO Auto-generated constructor stub
		super();
	} 
	public ResourceNotFoundException(String message) {
		super(message);
	}
}

